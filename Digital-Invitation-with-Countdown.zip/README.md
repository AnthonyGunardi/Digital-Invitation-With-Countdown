# Preview

![Thumbnail](/assets/images/banner.png)


## Demo

<https://ciptainsanaktif.com/invitation-2/?to=Anthony>


### Tech stack

- HTML5
- CSS
- Bootstrap 5.3.2
- AOS 2.3.4
- Fontawesome 6.5.0
- Normalize 8.0.1
- Google Fonts

### License

This digital invitation is open-sourced software licensed under the [MIT license](https://opensource.org/licenses/MIT).
